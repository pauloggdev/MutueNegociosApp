<?php

namespace App\empresa;

use Illuminate\Database\Eloquent\Model;

class TipoUser extends Model
{
    //
}
