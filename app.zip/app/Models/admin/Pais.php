<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class Pais extends Model
{
    protected $connection = 'mysql2';
    protected $table ='paises';

}
