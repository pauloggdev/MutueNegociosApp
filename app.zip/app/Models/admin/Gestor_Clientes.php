<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class Gestor_Clientes extends Model
{
    protected $connection = 'mysql';
    protected $table ='gestor_clientes';

}
