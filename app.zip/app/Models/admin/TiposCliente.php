<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class TiposCliente extends Model
{
    protected $connection = 'mysql';

}
