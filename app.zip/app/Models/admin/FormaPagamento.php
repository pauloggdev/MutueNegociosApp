<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;


class FormaPagamento extends Model
{
    protected $connection = 'mysql';
    protected $table ='formas_pagamentos';

    
}
