<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class Statu extends Model
{
    protected $table = 'status_gerais';
    protected $connection = 'mysql';

}
