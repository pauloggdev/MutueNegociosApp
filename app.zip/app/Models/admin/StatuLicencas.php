<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class StatuLicencas extends Model
{
    protected $table ='status_licencas';
    protected $connection = 'mysql';

}
