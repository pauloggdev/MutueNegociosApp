<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class TiposRegime extends Model
{
    protected $connection = 'mysql';
    protected $table ='tipos_regimes';
}
