<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class CanalComunicacao extends Model
{
    protected $table ='canais_comunicacoes';
    protected $connection = 'mysql';

}