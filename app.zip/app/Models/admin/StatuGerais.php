<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class StatuGerais extends Model
{
    protected $table ='status_gerais';
    protected $connection = 'mysql';

}
