<?php

namespace App\Models\admin;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    protected $connection = "mysql";
}
