<?php

namespace App\Models\empresa;

use Illuminate\Database\Eloquent\Model;

class Statu extends Model
{
    protected $table = 'status_gerais';
    protected $connection = 'mysql2';

}
