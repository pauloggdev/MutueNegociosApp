<?php

namespace App\Models\empresa;

use Illuminate\Database\Eloquent\Model;

class ParametroImpressao extends Model
{
    protected $table = "parametro_impressao";
}
