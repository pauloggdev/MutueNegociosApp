<?php

namespace App\Models\empresa;

use Illuminate\Database\Eloquent\Model;

class StatuFactura extends Model
{

    protected $table = "status_factura";
}
