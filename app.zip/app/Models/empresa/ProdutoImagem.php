<?php

namespace App\Models\empresa;

use Illuminate\Database\Eloquent\Model;

class ProdutoImagem extends Model
{
    protected $connection = 'mysql2';
    protected $table ='produto_imagens';

   
}
