<?php

namespace App\Models\empresa;

use Illuminate\Database\Eloquent\Model;

class ModeloDocumentoAtivo extends Model
{
    protected $table = 'modelo_documento_ativo';
    protected $connection = 'mysql2';
}
