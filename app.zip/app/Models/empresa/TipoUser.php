<?php

namespace App\Models\empresa;

use Illuminate\Database\Eloquent\Model;

class TipoUser extends Model
{
    protected $connection = 'mysql2';
    protected $table = 'tipo_users';
}
