<?php

namespace App\Models\empresa;

use Illuminate\Database\Eloquent\Model;

class CanalComunicacao extends Model
{
    protected $table ='canais_comunicacoes';
    protected $connection = 'mysql2';

}
