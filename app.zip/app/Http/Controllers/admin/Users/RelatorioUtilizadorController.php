<?php

namespace App\Http\Controllers\admin\Users;

use Livewire\Component;

class RelatorioUtilizadorController extends Component
{
    public function render()
    {
        return view('livewire.admin.relatorio-utilizador-controller');
    }
}
