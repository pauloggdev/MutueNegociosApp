<?php

namespace App\Http\Controllers;

class TypeInvoice
{
    const FACTURA_RECIBO = 1;
    const FACTURA = 2;
    const FACTURA_PROFORMA = 3;
    const STATUS_DIVIDA = 1;
    const STATUS_PAGO = 2;
    const NAO_CONVERTIDO = 1;
    const CONVERTIDO = 2;


}
