<?php

namespace App\Http\Controllers\empresa\Fornecedores;

use App\Repositories\Empresa\FornecedorRepository;
use Livewire\Component;

class FornecedorShowController extends Component
{


   
}
