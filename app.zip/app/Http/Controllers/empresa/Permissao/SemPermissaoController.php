<?php

namespace App\Http\Controllers\empresa\Permissao;

use Livewire\Component;

class SemPermissaoController extends Component
{

    public function render()
    {
        return view('empresa.permissoes.notPermission');
    }
}
