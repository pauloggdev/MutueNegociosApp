<?php

namespace App\Repositories\contracts;


interface StatuRepositoryInterface
{
    public function getStatu();
}
